# -*- coding: utf-8 -*-
"""
Created on Wed Jun 11 14:23:51 2025

@author: kagan
"""
import re
from openai import OpenAI

client = OpenAI(
    api_key="yourkey",
    base_url="https://openrouter.ai/api/v1"
)

model_name = "google/gemma-3-27b-it"

train_score_path = "yourpath\Radiolog Scores Few Shot Training.txt"
train_url_path = "yourpath\Few Shot Training.txt"
test_url_path = "yourpath\Few Shot Testing.txt"
output_path = "yourpath\Gemma3 API Scores Few Shot.txt"

def load_scores(path):
    scores = {}
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            match = re.match(r'"(.+?)\.tif":\s*([\d.]+),\s*(\w+)', line.strip())
            if match:
                filename = match.group(1) + ".png"
                scores[filename] = (float(match.group(2)), match.group(3))
    return scores

def load_urls(path):
    urls = {}
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            if ":" in line:
                parts = line.strip().split(":", 1)
                filename = parts[0].strip()
                url = parts[1].strip()
                urls[filename] = url
    return urls

def fewshotmessages(train_scores, train_urls, start_idx=0, count=10):
    messages = []
    items = list(train_scores.items())
    total = len(items)
    for i in range(count):
        idx = (start_idx + i) % total
        filename, (score, category) = items[idx]
        if filename in train_urls:
            url = train_urls[filename]
            messages.append({"role": "user", "content": [
                {"type": "text", "text": "Evaluate this CT scan image."},
                {"type": "image_url", "image_url": {"url": url}}
            ]})
            messages.append({"role": "assistant", "content": (
                f"Score (float): {score}\n"
                f"Category: {category}\n"
                f"Explanation: This CT scan was scored {score} ({category}). "
                f"The organs are {'well' if score > 3 else 'moderately' if score > 2 else 'poorly'} visible, "
                f"noise is {'minimal' if score > 3 else 'noticeable'}, and "
                f"contrast is {'adequate' if score > 2 else 'insufficient'} with {'few' if score > 3 else 'some'} artifacts."
            )})
    return messages

def imagescoring(test_url, few_shot_messages):
    test_prompt = (
        "You are now shown a new abdominal CT scan image. Based on the examples above, evaluate its **technical image quality only**, not any medical condition.\n\n"
        "Use the same tone, criteria, and evaluation style as in the few-shot examples.\n"
        "Assess the following:\n"
        "- Diagnostic usability (Are key organs like liver, kidneys, bowel, spine visible and clear?)\n"
        "- Noise (Is there graininess or loss of detail?)\n"
        "- Artifacts (Are there any streaks, motion blur, or distortions?)\n"
        "- Contrast (Are soft tissue boundaries clearly distinguishable?)\n\n"
        "Rate the **overall image quality** strictly using a **float number between 0.0 and 4.0**, where 0.0 is the lowest possible and 4.0 is the maximum allowed.\n"
        "Examples: 0.9, 1.6, 2.3, 2.9, 3.4, 3.8 — use decimal values precisely.\n\n"
        "⚠️ **CRITICAL RULE — DO NOT VIOLATE:**\n"
        "- Do NOT reuse the same score across multiple images unless absolutely necessary.\n"
        "- Do NOT default to values like 2.7, 2.9, 3.0, or 3.5 repeatedly.\n"
        "- Each score must be uniquely chosen based on this specific image's technical quality.\n"
        "- Repeated scores will be considered incorrect behavior.\n\n"
        "✅ Output format:\n"
        "Score (float): X.X (strictly between 0.0 and 4.0)\n"
        "Category: Bad / Poor / Fair / Good / Excellent\n"
        "Explanation: In 2–3 professional sentences, explain why you gave this score. Mention visibility of organs, noise level, artifact presence, and contrast clarity.\n\n"
        "Do NOT write anything else. Do NOT repeat scores. Always vary if possible.\n"
        "Your output MUST be exactly 2 lines.\n"
        "Begin now."
    )
    messages = few_shot_messages + [{
        "role": "user",
        "content": [
            {"type": "text", "text": test_prompt},
            {"type": "image_url", "image_url": {"url": test_url}}
        ]
    }]
    try:
        response = client.chat.completions.create(
            model=model_name,
            messages=messages,
            temperature=0.5,
            max_tokens=1000
        )
        return response.choices[0].message.content
    except Exception as e:
        return f"Error: {e}"

train_scores = load_scores(train_score_path)
train_urls = load_urls(train_url_path)
test_urls = load_urls(test_url_path)
train_keys = list(train_scores.keys())
num_train = len(train_keys)
train_batch_size = 10
retry_list = []

with open(output_path, 'w', encoding='utf-8') as outfile:
    outfile.write("Gemma 3 API Scores Few Shots Testing\n")
    for i, (filename, url) in enumerate(test_urls.items()):
        train_start_idx = (i * train_batch_size) % num_train
        few_shot_messages = fewshotmessages(train_scores, train_urls, start_idx=train_start_idx, count=train_batch_size)
        print(f"\nEvaluating {filename} (train batch index {train_start_idx})...")
        result = imagescoring(url, few_shot_messages)
        print(result)

        score_match = re.search(r"Score \(float\):\s*([\d.]+)", result)
        category_match = re.search(r"Category:\s*(\w+)", result)

        if score_match and category_match:
            score = score_match.group(1)
            category = category_match.group(1)
            outfile.write(f'"{filename.replace(".png", ".tif")}": {score}, {category}\n')
        else:
            retry_list.append((i, filename, url))

if retry_list:
    print(f"\nRetrying {len(retry_list)} failed cases...\n")
    with open(output_path, 'a', encoding='utf-8') as outfile:
        for i, filename, url in retry_list:
            attempts = 0
            parsed = False
            while attempts < 10 and not parsed:
                train_start_idx = (i * train_batch_size) % num_train
                few_shot_messages = fewshotmessages(train_scores, train_urls, start_idx=train_start_idx, count=train_batch_size)
                print(f"\nRetrying {filename} (attempt {attempts + 1})...")
                result = imagescoring(url, few_shot_messages)
                print(result)

                score_match = re.search(r"Score \(float\):\s*([\d.]+)", result)
                category_match = re.search(r"Category:\s*(\w+)", result)

                if score_match and category_match:
                    score = score_match.group(1)
                    category = category_match.group(1)
                    outfile.write(f'"{filename.replace(".png", ".tif")}": {score}, {category}\n')
                    parsed = True
                else:
                    attempts += 1

            if not parsed:
                outfile.write(f'"{filename.replace(".png", ".tif")}": Final error in parsing result\n')

with open(output_path, 'r', encoding='utf-8') as infile:
    lines = infile.readlines()

header = lines[0]
valid_lines = []

for line in lines[1:]:
    match = re.match(r'"(.+?\.tif)":\s*([\d.]+),\s*(\w+)', line.strip())
    if match:
        valid_lines.append(line)

with open(output_path, 'w', encoding='utf-8') as outfile:
    outfile.write(header)
    outfile.writelines(valid_lines)
